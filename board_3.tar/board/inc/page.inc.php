<?
##############################################################################################################
###################                                                                     ######################
###################    Установка и настройка Joker Board Commercial 3 ==> ICQ:183917    ######################
###################                                                                     ######################
##############################################################################################################

$query_pages=mysql_query ("SELECT id,title FROM jb_page WHERE menu='yes' ORDER by sort_index"); cq();  
if(@mysql_num_rows(@$query_pages)){
	echo "<div class=\"cornhc\"><div class=\"cornhl\"></div><div class=\"cornhr\"></div><h3>".$lang[1096]."</h3></div><div class=\"lmenu\">";
	while($page=mysql_fetch_assoc($query_pages))echo "<p class=\"links\"><a href=\"".$h."p".$page['id'].".html\">".$page['title']."</a></p>";
	echo "</div>";
}
?>