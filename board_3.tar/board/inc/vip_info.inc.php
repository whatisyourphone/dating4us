<?
##############################################################################################################
###################                                                                     ######################
###################    Установка и настройка Joker Board Commercial 3 ==> ICQ:183917    ######################
###################                                                                     ######################
##############################################################################################################

if($c['wm_money_service']=="yes"){
	mysql_query("INSERT INTO jb_stat_wm SET id_board='".$_GET['id_mess']."',date=NOW()") or die(mysql_error());
	$last_id=mysql_insert_id();
}
?><h1 class="orange alcenter"><?=$lang[1127]?></h1><span class="gray"><?=$lang[1128]?> <a href="<?=$h?>p10.html"><?=$lang[1129]?></a>.</span><br /><br /><br /><div align="center"><img src="<?=$im?>vip.gif" alt="<?=$lang[1130]?>" class="absmid" /> <a class="red b" style="margin-right:20px; border-bottom:1px dashed; text-decoration:none" href="#" onclick="details2(1);return false;"><?=$lang[1130]?></a> <img src="<?=$im?>lost.gif" alt="<?=$lang[1131]?>" class="absmid" /> <a class="green b" style="border-bottom:1px dashed; text-decoration:none" href="#" onclick="details2(2);return false;"><?=$lang[1131]?></a><div id="1" style="display:none; padding:5px; margin:20px;"><?
if($c['money_service']=="yes"){
	?><div style="padding:10px;border: 2px dashed #F60;background-color:#FFFDF2"><div style="float:right;"><img src="<?=$im?>mob.gif" alt="SMS" /></div><?=$lang[1132]?><br /><br /><span class="red large"><strong><?=$c['top_prefix']?> <?=$_GET['id_mess']?></strong></span> <span class="large"><?=$lang[517]?> <strong><?=$c['top_number']?></strong></span><br /><br /><span class="orange b"><?=$lang[518]?> "<?=$c['top_prefix']?>" <?=$lang[519]?> "<?=$_GET['id_mess']?>" <?=$lang[1110]?></span><br /><br /><span class="sm"><?=$lang[1133]?> <?=$c['top_price']?>.<br /><?=$lang[1109]?> <a href="http://num.smsonline.ru/?<?=$c['top_number']?>" target="_blank"><?=$lang[520]?></a></span></div><?	
}
if($c['money_service']=="yes" && $c['wm_money_service']=="yes") echo "<br /><h1 class=\"red\">ИЛИ</h1><br />";
if($c['wm_money_service']=="yes"){
	$pay_descr=$lang[1136].$lang[1141]." ".$_GET['id_mess']." ".$lang[1137];
	?><div style="padding:10px;border: 2px dashed #F60;background-color:#FFFDF2"><div style="float:right;"><img src="<?=$im?>wm_logo.gif" alt="WebMoney" /></div><?=$lang[1134]?> <a href="http://www.webmoney.ru/rus/index.shtml" rel="nofollow">WebMoney</a><br /><span class="sm"><?=$lang[1135]?> <strong><?=$c['wmprice_vip']?> <?=$c['wm_type']?></strong></span><br /><br /><form accept-charset="windows-1251" method="post" action="https://merchant.webmoney.ru/lmi/payment.asp"><input type="hidden" name="LMI_PAYMENT_AMOUNT" value="<?=$c['wmprice_vip']?>" /><input type="hidden" name="LMI_PAYMENT_DESC" value="<?=$pay_descr?>" /><input type="hidden" name="LMI_PAYMENT_NO" value="<?=$last_id?>" /><input type="hidden" name="LMI_PAYEE_PURSE" value="<?=$c['wm_purse']?>" /><?
	if($c['wm_mode']=="on")echo "<input type=\"hidden\" name=\"LMI_SIM_MODE\" value=\"0\" />";
	?><input type="hidden" name="id_board" value="<?=$_GET['id_mess']?>" /><input type="hidden" name="type" value="vip" /><input type="hidden" name="last_id" value="<?=$last_id?>" /><input type="submit" value="<?=$lang[1138]?> (<?=$c['wmprice_vip']?> <?=$c['wm_type']?>)" /></form></div><?	
}
?></div><div id="2" style="display:none; padding:5px; margin:20px;"><?
if($c['money_service']=="yes"){
	?><div style="padding:10px;border: 2px dashed #090;background-color:#F5FFF2"><div style="float:right;"><img src="<?=$im?>mob.gif" alt="SMS" /></div><?=$lang[1139]?><br /><br /><span class="red large"><strong><?=$c['select_prefix']?> <?=$_GET['id_mess']?></strong></span> <span class="large"><?=$lang[517]?> <strong><?=$c['select_number']?></strong></span><br /><br /><span class="orange b"><?=$lang[518]?> "<?=$c['select_prefix']?>" <?=$lang[519]?> "<?=$_GET['id_mess']?>" <?=$lang[1110]?></span><br /><br /><span class="sm"><?=$lang[1133]?> <?=$c['select_price']?>.<br /><?=$lang[1109]?> <a href="http://num.smsonline.ru/?<?=$c['select_number']?>" target="_blank"><?=$lang[520]?></a></span></div><?	
}
if($c['money_service']=="yes" && $c['wm_money_service']=="yes") echo "<br /><h1 class=\"red\">ИЛИ</h1><br />";
if($c['wm_money_service']=="yes"){
	$pay_descr=$lang[1140].$lang[1141]." ".$_GET['id_mess'];
	?><div style="padding:10px;border: 2px dashed #090;background-color:#F5FFF2"><div style="float:right;"><img src="<?=$im?>wm_logo.gif" alt="WebMoney" /></div><?=$lang[1134]?> <a href="http://www.webmoney.ru/rus/index.shtml" rel="nofollow">WebMoney</a><br /><span class="sm"><?=$lang[1135]?> <strong><?=$c['wmprice_select']?> <?=$c['wm_type']?></strong></span><br /><br /><form accept-charset="windows-1251" method="post" action="https://merchant.webmoney.ru/lmi/payment.asp"><input type="hidden" name="LMI_PAYMENT_AMOUNT" value="<?=$c['wmprice_select']?>" /><input type="hidden" name="LMI_PAYMENT_DESC" value="<?=$pay_descr?>" /><input type="hidden" name="LMI_PAYMENT_NO" value="<?=$last_id?>" /><input type="hidden" name="LMI_PAYEE_PURSE" value="<?=$c['wm_purse']?>" /><?
	if($c['wm_mode']=="on")echo "<input type=\"hidden\" name=\"LMI_SIM_MODE\" value=\"0\" />";
	?><input type="hidden" name="id_board" value="<?=$_GET['id_mess']?>" /><input type="hidden" name="type" value="sel" /><input type="hidden" name="last_id" value="<?=$last_id?>" /><input type="submit" value="<?=$lang[1138]?> (<?=$c['wmprice_select']?> <?=$c['wm_type']?>)" /></form></div><?	
}
?></div></div><br /><span class="sm gray"><?=$lang[521]?> - <a href="<?=$h?>contacts.html"><?=$lang[522]?></a> <?=$lang[523]?></span>