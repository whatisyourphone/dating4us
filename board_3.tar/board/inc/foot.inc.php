﻿<div id="nojs"><?=$lang[1007]?></div><script type="text/javascript">$('nojs').style.display='none';</script><script type="text/javascript" src="<?=$im?>viewer.js"></script><div class="footer"><div class="subfooter_right"><img src="<?=$im?>logoj.gif" alt="<?=$lang[1144]?>" /><br /><br />
<!-- Начало / сюда вставляем коды счётчиков, кнопок и т.п. хлам -->

<a href="http://seocola.ru/seotools/" target="_blank" title="СКРИПТЫ "><img src="http://seocola.ru/seo-cntr-mgncom.ru-8" border="0" alt="СКРИПТЫ"></a>

<!-- Конец / сюда вставляем коды счётчиков, кнопок и т.п. хлам -->
</div><div class="subfooter"><!--Queries: <?=$GLOBALS['cq']?> | <?=utf8_substr(gentime(),0,6)?>sec.--><a href="<?=$h?>"><?=$h?></a> &copy;<?=date("Y")?><br /><?=$lang[592]?> <a href="<?=$h?>p6.html"><?=$lang[593]?></a><br /><br />
<?=$lang[1145]?> <?=$lang[1146]?> SEOCOLA.RU</div></div></body></html>