<?
##############################################################################################################
###################                                                                     ######################
###################    Установка и настройка Joker Board Commercial 3 ==> ICQ:183917    ######################
###################                                                                     ######################
##############################################################################################################

if(defined('JBCITY')) $GLOBALS['subQuery']=' AND city_id = '.JBCITY; else $GLOBALS['subQuery']='';
function listcat2($id, $sub){
	$categories = mysql_query("SELECT id, child_category, name_cat, en_name_cat FROM jb_board_cat WHERE root_category = $id ORDER by sort_index"); cq(); 
	while($category = mysql_fetch_assoc($categories)){	
		$name_cat = (defined('JBLANG') && constant('JBLANG')=='en') ? $category['en_name_cat'] : $category['name_cat'];
		$count_ads = mysql_result(mysql_query("SELECT COUNT(id) from jb_board WHERE id_category='".$category['id']."' AND old_mess='old'".$GLOBALS['subQuery']), 0);cq();
		if($sub=="1") $subclass=" class=\"subclass\" ";else $subclass="";
		echo "<a ".$subclass." href=\"c".$category['id'].".html\">".$name_cat."</a> (".@$count_ads.")<br />";
		if($category['child_category']==1){listcat2($category['id'],$sub+1);echo "<br />";}
	}
}
$categories = mysql_query("SELECT id, child_category, name_cat, en_name_cat, img FROM jb_board_cat WHERE root_category='".$cattitle['id']."' ORDER by sort_index");  cq();
echo "<div class=\"alcenter\"><h1 class=\"orange\">".$cattitle[$name_cat];
if(defined('USER_CITY_TITLE')) echo ", ".USER_CITY_TITLE;
echo "</h1></div><br /><br />";
echo "<div class=\"index_cat gray sm\">"; 
while($category = mysql_fetch_assoc($categories)){
	$name_cat = (defined('JBLANG') && constant('JBLANG')=='en') ? $category['en_name_cat'] : $category['name_cat'];
	echo (@$category['img'])?"<img alt=\"".$name_cat."\" class=\"rootcatimg\" src=\"".$u."cat/".$category['img']."\" />":"";
	if($category['child_category']==1){
		echo "<span class=\"rootcat\">".$name_cat."</span><br />";
		listcat2($category['id'],1);
		echo "<br />";
	}else{
		$count_ads = mysql_result(mysql_query("SELECT COUNT(id) from jb_board WHERE id_category='".$category['id']."' AND old_mess='old'".$GLOBALS['subQuery']), 0);cq();
		echo "<a href=\"c".$category['id'].".html\">".$name_cat."</a> (".@$count_ads.")<br />";
	}
}
echo "</div><div class=\"clear\"></div>";
?>
