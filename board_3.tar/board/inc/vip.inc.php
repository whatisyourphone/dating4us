<?
##############################################################################################################
###################                                                                     ######################
###################    Установка и настройка Joker Board Commercial 3 ==> ICQ:183917    ######################
###################                                                                     ######################
##############################################################################################################

$query_vip=mysql_query("SELECT jb_board.id, jb_board.id_category, jb_board.title, jb_board.text, jb_photo.photo_name FROM jb_board LEFT JOIN jb_photo ON jb_board.id = jb_photo.id_message WHERE jb_board.old_mess='old' AND jb_board.checkbox_top=1 GROUP by jb_board.id ORDER by jb_board.checkbox_top DESC, jb_board.top_time DESC, jb_board.id DESC LIMIT ".$c['count_print_vip']);cq();
if(mysql_num_rows($query_vip)){
	echo "<div class=\"cornhc\"><div class=\"cornhl\"></div><div class=\"cornhr\"></div><h3>".$lang[591]."</h3></div><div class=\"lvip\"><div class=\"alcenter\"><a class=\"red b\" href=\"".$h."p10.html\" title=\"".$lang[1097]."\">".$lang[1097]."</a></div><br />";	
	while($vip_ads=mysql_fetch_assoc($query_vip)){
		if(utf8_strlen($vip_ads['text'])>100)$vip_ads['text']=utf8_substr($vip_ads['text'],0,97)."...";
		if(@$vip_ads['photo_name']!="")$vip_ads_img="<br /><img alt=\"".$vip_ads['title']."\" src=\"".$u."small/".$vip_ads['photo_name']."\" />";else $vip_ads_img="";
		echo "<p><a href=\"".$h."c".$vip_ads['id_category']."-".$vip_ads['id'].".html\">".$vip_ads['title']."</a><br />".$vip_ads_img."</p><div>".$vip_ads['text']."</div><div class=\"linec\">&nbsp;</div>";
	}
	echo "</div>";
}
?>

